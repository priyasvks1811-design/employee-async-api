package com.priya.employee_async_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeAsyncApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeAsyncApiApplication.class, args);
	}

}
